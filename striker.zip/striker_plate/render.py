"""
Render the striker plate without OpenGL: matplotlib 3D, per-face shading.

The camera look direction and the shading backface culling are both derived
from (elev, azim) so they always agree. All three axes share one symmetric
data span and a cubic box -> true orthographic proportions.

Views → output/:
  front.png   dead-on front elevation of the faceplate
  iso.png     3/4 isometric preview
  back.png    rear elevation (shows the stepped rider lug)
Neutral light-grey background, matte-black metal shading, soft contact shadow.
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import trimesh

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
BG = "#e8e8e8"


def _camera_dir(elev: float, azim: float) -> np.ndarray:
    """World-space unit vector from origin toward the camera (view = -this)."""
    el, az = np.radians(elev), np.radians(azim)
    return np.array([np.cos(el) * np.cos(az),
                     np.cos(el) * np.sin(az),
                     np.sin(el)])


def render(mesh: trimesh.Trimesh, elev: float, azim: float, fname: str):
    cam = _camera_dir(elev, azim)          # origin -> camera
    view = -cam                            # camera -> origin
    light = np.array([-0.5, 0.35, 0.85]); light /= np.linalg.norm(light)

    tri = mesh.vertices[mesh.faces]
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    ln = np.linalg.norm(n, axis=1, keepdims=True); ln[ln == 0] = 1.0
    n = n / ln

    vis = np.einsum("ij,j->i", n, -view) > 0           # backface cull

    base = np.array([0.040, 0.040, 0.045])             # matte black metal
    diff = np.maximum(np.einsum("ij,j->i", n, light), 0.0)
    half = light - view; half /= np.linalg.norm(half)
    spec = np.maximum(np.einsum("ij,j->i", n, half), 0.0) ** 20.0
    shade = np.clip(0.32 + 0.68 * diff + 0.30 * spec, 0.0, 1.0)
    color = base[None, :] * shade[:, None]

    fig = plt.figure(figsize=(7.2, 7.2))
    fig.patch.set_facecolor(BG)
    ax = fig.add_subplot(111, projection="3d", proj_type="ortho")
    ax.set_facecolor(BG)

    # --- symmetric data span on every axis -> equal unit scale, true proportions
    lo, hi = mesh.bounds
    span = (hi - lo).max()
    c = mesh.centroid
    r = span / 2 + 0.12 * span
    ax.set_xlim(c[0] - r, c[0] + r)
    ax.set_ylim(c[1] - r, c[1] + r)
    ax.set_zlim(c[2] - r, c[2] + r)
    ax.set_box_aspect((1, 1, 1))

    # --- soft contact shadow on the ground plane (isometric view only)
    if fname == "iso.png":
        ymin = lo[1]
        t = np.linspace(0, 2 * np.pi, 80)
        sh = np.stack([0.55 * np.sin(t), np.full_like(t, ymin),
                       0.35 * np.cos(t)], axis=1) + np.array([0.0, 0.0, c[2]])
        ax.add_collection3d(
            Poly3DCollection([sh], color="#c1c1c1", alpha=0.9, zorder=0))

    # --- object
    pc = Poly3DCollection(tri[vis], zsort="average")
    pc.set_facecolor(color[vis])
    pc.set_edgecolor("none")
    ax.add_collection3d(pc)

    ax.view_init(elev=elev, azim=azim)
    ax.set_axis_off()
    fig.subplots_adjust(left=0, right=1, top=1, bottom=0)
    fig.savefig(os.path.join(OUT, fname), dpi=160, facecolor=BG)
    plt.close(fig)


def main():
    m = trimesh.load(os.path.join(OUT, "striker_plate.glb"), force="mesh")
    render(m, elev=88.5, azim=90.0, fname="front.png")   # faceplate elevation
    render(m, elev=20.0, azim=-60.0, fname="iso.png")    # 3/4 preview
    render(m, elev=-88.5, azim=90.0, fname="back.png")   # rear elevation
    render(m, elev=0.0, azim=0.0, fname="profile.png")   # end view: lug step
    print("previews → output/front.png, output/iso.png, output/back.png, output/profile.png")


if __name__ == "__main__":
    main()


if __name__ == "__main__":
    main()