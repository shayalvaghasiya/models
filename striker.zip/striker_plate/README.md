# Sliding Window/Door Lock — Striker Plate

Watertight manifold 3D model, generated programmatically (trimesh + manifold3d).

## Dimensions (cm)
- **Front faceplate:** 10 (H) × 1 (W) × 0.5 (thick)
- **Holes (through faceplate only):**
  - bottom screw hole — Ø0.36, centre 1.0 from bottom edge
  - top screw hole — Ø0.36, centre 9.0 from bottom edge
  - round latch hole — Ø0.60, centre 7.0 from bottom edge
- **Rear locking lug (projection):** spans 2.5–8.0 cm of the height,
  width 0.50 (half the plate), depth 0.80 behind the plate → sits stepped
  behind the front faceplate.

## Files (`output/`)
| file             | description                                        |
|------------------|----------------------------------------------------|
| `striker_plate.stl` | binary STL (mesh only)                          |
| `striker_plate.glb` | glTF with matte-black PBR material             |
| `front.png`      | front elevation (faceplate)                       |
| `back.png`       | rear elevation (shows lug step)                   |
| `profile.png`    | end view (shows lug projecting behind plate)      |
| `iso.png`        | 3/4 isometric, neutral background                 |

## Regenerate
```
python generate.py   # mesh → STL + PBR GLB
python render.py     # preview PNGs (matplotlib, no OpenGL)
```
Adjust the dimension constants at the top of `generate.py` to re-parameterise.
