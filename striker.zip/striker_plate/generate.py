"""
Striker plate for a sliding window / sliding-door lock.
Parametric, watertight manifold mesh (built with manifold3d via trimesh).

Dimensions (cm):
  Front faceplate : 10 (H) x 1 (W) x 0.5 (thick)
  Holes (through the faceplate thickness only):
    - two screw holes (cylindrical through-holes) at the bottom and top sections
    - one larger round (latch) hole in the top section
  Rear locking lug: rectangular projection stepped behind the front plate,
    spanning 2.5 -> 8 cm of the height, 0.5 cm wide (half the plate width),
    0.5 cm thick plate + 0.8 cm rear projection depth.

Axes: x = width, y = height, z = thickness (plate z in [-0.25, +0.25]; rear is -z).
Output: striker_plate.stl, striker_plate.glb, preview PNGs.
"""
import os
import numpy as np
import trimesh

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
os.makedirs(OUT, exist_ok=True)

# ----------------------------------------------------------------------------
# Parameters (cm)
# ----------------------------------------------------------------------------
PLATE_W, PLATE_H, PLATE_T = 1.0, 10.0, 0.5          # front faceplate

SCREW_R = 0.18                                     # screw hole radius  (Ø0.36)
ROUND_R = 0.30                                     # latch hole radius  (Ø0.60)

TOP_Y   = 9.0                                      # top screw hole centre
ROUND_Y = 7.0                                      # round (latch) hole centre
BOT_Y   = 1.0                                      # bottom screw hole centre

LUG_W   = 0.5                                      # lug width = half plate width
LUG_Y0, LUG_Y1 = 2.5, 8.0                          # lug height extent on the plate
LUG_D   = 0.8                                      # rear projection depth

HOLE_SECTIONS = 64                                 # smooth round holes


def _hole(radius: float, y_from_bottom: float) -> trimesh.Trimesh:
    """Cylinder that cuts a through-hole in the faceplate only (z in plate)."""
    c = trimesh.creation.cylinder(radius=radius, height=PLATE_T + 1e-6,
                                  sections=HOLE_SECTIONS)
    c.apply_translation([0.0, y_from_bottom - PLATE_H / 2.0, 0.0])
    return c


def build() -> trimesh.Trimesh:
    # Plate centred at origin, y in [-H/2, +H/2].
    plate = trimesh.creation.box(extents=[PLATE_W, PLATE_H, PLATE_T])

    # Rear locking lug: stepped behind the front plate (attached to back face).
    y_c = (LUG_Y0 + LUG_Y1) / 2.0 - PLATE_H / 2.0
    lug = trimesh.creation.box(extents=[LUG_W, LUG_Y1 - LUG_Y0, LUG_D])
    lug.apply_translation([0.0, y_c, -PLATE_T / 2.0 - LUG_D / 2.0])

    body = plate.union(lug, engine="manifold")
    for y in (BOT_Y, TOP_Y):
        body = body.difference(_hole(SCREW_R, y), engine="manifold")
    body = body.difference(_hole(ROUND_R, ROUND_Y), engine="manifold")

    body.merge_vertices()
    body.fix_normals()
    body.process(validate=True)
    return body


def main() -> None:
    m = build()

    print(f"vertices : {len(m.vertices)}")
    print(f"faces    : {len(m.faces)}")
    print(f"watertight : {m.is_watertight}")
    print(f"consistent : {m.is_winding_consistent}")
    print(f"volume   : {m.volume:.4f} cm^3  ({m.volume * 1000:.1f} mm^3)")
    print(f"bounds   : {np.round(m.bounds, 3).tolist()}")
    assert m.is_watertight and m.is_winding_consistent, "mesh not manifold!"

    m.export(os.path.join(OUT, "striker_plate.stl"))

    # Matte-black painted hardware PBR material (GLB only).
    mat = trimesh.visual.material.PBRMaterial(
        baseColorFactor=[0.035, 0.035, 0.038, 1.0],   # matte black
        metallicFactor=0.10,                          # painted steel
        roughnessFactor=0.92,                         # matte finish
    )
    m.visual = trimesh.visual.TextureVisuals(material=mat)
    trimesh.Scene(m).export(os.path.join(OUT, "striker_plate.glb"))

    print(f"wrote → {OUT}/striker_plate.{{stl,glb}}")


if __name__ == "__main__":
    main()